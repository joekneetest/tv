package com.example.tvlauncher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val ACCENT = 0xFFBB86FC.toInt()
private const val SURFACE = 0xFF241C3D.toInt()

class MainActivity : Activity() {

    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var grid: RecyclerView
    private val adapter = AppAdapter()
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            date.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
            handler.postDelayed(this, 15_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(56), dp(32), dp(56), 0)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF0E0A1F.toInt(), 0xFF2A1B4D.toInt())
            )
        }

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        clock = TextView(this).apply { textSize = 56f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-light", Typeface.NORMAL) }
        date = TextView(this).apply { textSize = 20f; setTextColor(0xFFB9ADD6.toInt()); setPadding(dp(20), 0, 0, dp(12)) }
        header.addView(clock); header.addView(date)
        root.addView(header)

        grid = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 5)
            adapter = this@MainActivity.adapter
            clipToPadding = false
            clipChildren = false
            setPadding(0, dp(24), 0, dp(48))
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        adapter.submit(loadApps())
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        grid.smoothScrollToPosition(0) // Home pressed again
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* a launcher doesn't exit */ }

    private fun loadApps(): List<ResolveInfo> {
        val pm = packageManager
        fun query(cat: String) = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)
        return (query(Intent.CATEGORY_LEANBACK_LAUNCHER) + query(Intent.CATEGORY_LAUNCHER))
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
    }

    private fun launch(ri: ResolveInfo) {
        val i = Intent(Intent.ACTION_MAIN).apply {
            component = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(i)
    }

    private fun appInfo(ri: ResolveInfo) {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ri.activityInfo.packageName}")))
    }

    inner class AppAdapter : RecyclerView.Adapter<AppAdapter.VH>() {
        private var items: List<ResolveInfo> = emptyList()
        fun submit(l: List<ResolveInfo>) { items = l; notifyDataSetChanged() }

        inner class VH(val card: LinearLayout, val img: ImageView, val label: TextView) : RecyclerView.ViewHolder(card)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val d = parent.resources.displayMetrics.density
            fun dp(v: Int) = (v * d).toInt()
            val card = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                isFocusable = true
                isClickable = true
                layoutParams = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    setMargins(dp(10), dp(10), dp(10), dp(10))
                }
                setPadding(dp(6), dp(6), dp(6), dp(6))
                background = StateListDrawable().apply {
                    addState(intArrayOf(android.R.attr.state_focused), GradientDrawable().apply {
                        cornerRadius = dp(16).toFloat(); setColor(SURFACE); setStroke(dp(3), ACCENT)
                    })
                    addState(intArrayOf(), GradientDrawable().apply {
                        cornerRadius = dp(16).toFloat(); setColor(0x00000000)
                    })
                }
            }
            val box = FrameLayout(parent.context).apply {
                background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(SURFACE) }
                clipToOutline = true
            }
            val img = ImageView(parent.context).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            box.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            card.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(110)))
            val label = TextView(parent.context).apply {
                textSize = 15f; setTextColor(Color.WHITE); maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(4))
            }
            card.addView(label)
            card.setOnFocusChangeListener { v, focus ->
                v.animate().scaleX(if (focus) 1.1f else 1f).scaleY(if (focus) 1.1f else 1f).setDuration(120).start()
                v.elevation = if (focus) 12 * d else 0f
            }
            return VH(card, img, label)
        }

        override fun onBindViewHolder(h: VH, pos: Int) {
            val ri = items[pos]
            val pm = packageManager
            val banner = ri.activityInfo.loadBanner(pm)
            if (banner != null) {
                h.img.scaleType = ImageView.ScaleType.CENTER_CROP
                h.img.setPadding(0, 0, 0, 0)
                h.img.setImageDrawable(banner)
            } else {
                val p = (28 * h.card.resources.displayMetrics.density).toInt()
                h.img.scaleType = ImageView.ScaleType.FIT_CENTER
                h.img.setPadding(p, p / 2, p, p / 2)
                h.img.setImageDrawable(ri.loadIcon(pm))
            }
            h.label.text = ri.loadLabel(pm)
            h.card.setOnClickListener { launch(ri) }
            h.card.setOnLongClickListener { appInfo(ri); true }
        }

        override fun getItemCount() = items.size
    }
}
